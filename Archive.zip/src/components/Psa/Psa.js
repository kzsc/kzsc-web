import React, { Component } from 'react';
import {  } from 'semantic-ui-react'

class Psa extends Component{

  constructor() {
    super();
    this.state = {};
  }

  render() {
    return (
      <div className="Psa"></div>
    );
  }

}

export default Psa;
